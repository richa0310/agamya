<!DOCTYPE html>
<html lang="en">
<head>
  <title>Home page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="loginform.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>
 <header>
  <div class="row">
      <div class="col-md-2" align="center">
        <a href="#" onclick="window.open('https://www.nitt.edu/')"><img src="images/nitlogo2.png" class="nlogo"></a>
      </div>
      <div class="col-md-8">
        
      </div>
      <div class="col-md-2" align="center">
        <a href="#" onclick="window.open('http://osoc.nitt.edu/')"><img src="images/osoc.png" class="ologo"></a>
      </div>
     </div>
 </header>
 <div class="login-wrap">
  <div class="login-html">
    <input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Sign In</label>
    <input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Sign Up</label>
    <div class="login-form">
      <form class="sign-in-htm" action="login.php" method="GET">
        <div class="group">
          <br>
          <input id="username" name="username" type="text" class="input" placeholder="Enter Username">
        </div>
        <div class="group">
          <br>
          <input id="password" name="password" type="password" class="input" data-type="password" placeholder="Enter Password">
        </div>
        <br>
        <div class="group">
          <input type="submit" class="button" value="Sign In">
        </div>
      </form>
      <form class="sign-up-htm" action="signup.php" method="POST">
        <div class="group">
          <input id="username" name="username" type="text" class="input" placeholder="Enter Username">
        </div><br>
        <div class="group">
          <input id="password" name="password" type="password" class="input" data-type="password" placeholder="Enter Password">
        </div>
        <div class="group"><br>
          <input id="pass" type="password" class="input" data-type="password" placeholder="Confirm Password">
        </div><br>
        <div class="group">
          <input type="submit" class="button" value="Sign Up">
        </div>
        <div class="foot-lnk">
          <label for="tab-1">Already Member?</a>
        </div>
      </form>
    </div>
  </div>
</div>
  

</body>
</html>
